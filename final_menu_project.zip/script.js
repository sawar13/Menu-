document.addEventListener('DOMContentLoaded', () => {
    displayMenuItems();
    displayMostOrdered();
});

// قائمة الأطباق
const menuItems = [
    { id: 1, name: 'بيتزا مارغريتا', price: 15, image: 'images/dish1.webp', orders: 50 },
    { id: 2, name: 'شاورما لحم', price: 12, image: 'images/dish2.webp', orders: 75 },
    { id: 3, name: 'طبق المكرونة', price: 10, image: 'images/dish3.webp', orders: 20 },
    { id: 4, name: 'سلطة قيصر', price: 8, image: 'images/dish4.webp', orders: 40 },
];

// عرض الأطباق
function displayMenuItems() {
    const menuGrid = document.getElementById('menu-grid');
    menuGrid.innerHTML = '';

    menuItems.forEach(item => {
        menuGrid.innerHTML += `
            <div class="menu-item">
                <img src="${item.image}" alt="${item.name}" loading="lazy" />
                <h3>${item.name}</h3>
                <p>السعر: ${item.price}$</p>
                <button class="btn btn-primary" onclick="addToOrder(${item.id})">أضف إلى الطلب</button>
            </div>
        `;
    });
}

// عرض الأكثر طلبًا
function displayMostOrdered() {
    const popularContainer = document.querySelector('.carousel');
    popularContainer.innerHTML = '';

    menuItems
        .sort((a, b) => b.orders - a.orders)
        .slice(0, 3)
        .forEach(item => {
            popularContainer.innerHTML += `
                <div class="carousel-item">
                    <img src="${item.image}" alt="${item.name}" loading="lazy" />
                    <h3>${item.name}</h3>
                    <p>السعر: ${item.price}$</p>
                </div>
            `;
        });
}
